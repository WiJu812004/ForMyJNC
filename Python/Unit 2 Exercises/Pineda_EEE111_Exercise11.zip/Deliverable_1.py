import math
import matplotlib.pyplot as plt

def cos_wave(time_points, frequency):
    """
    Calculates the cosine wave for a list of time points.
    
    Args:
        time_points (list): A list of time values in seconds.
        frequency (float): Frequency in Hertz.
        
    Returns:
        list: A list of amplitude values.
    """
    # We use a list comprehension to apply the math.cos function to every item in the list
    return [math.cos(2 * math.pi * frequency * t) for t in time_points]

# --- Usage Example ---

# 1. Generate the time list 't' manually (0 to 10ms)
# We want 1000 points to make the graph smooth.
start_time = 0.0
end_time = 0.010
num_points = 1000
step_size = (end_time - start_time) / num_points

# Creating the list [0.0, 0.00001, 0.00002, ... 0.010]
t = [start_time + i * step_size for i in range(num_points)]

# 2. Set Frequency
frequency = 1000

# 3. Generate the wave
y = cos_wave(t, frequency)

# 4. Plot (Matplotlib accepts standard Python lists)
plt.plot(t, y)
plt.show()